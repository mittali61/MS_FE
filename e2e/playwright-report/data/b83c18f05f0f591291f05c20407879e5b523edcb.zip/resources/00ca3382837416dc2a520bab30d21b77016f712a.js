import{k as r,aF as e,r as t,aI as o}from"./index-BOdEhjVx.js";function u(s){const a=r();a(e(s)),t.useEffect(()=>()=>{a(o(s.key))},[s.key,a])}export{u};
