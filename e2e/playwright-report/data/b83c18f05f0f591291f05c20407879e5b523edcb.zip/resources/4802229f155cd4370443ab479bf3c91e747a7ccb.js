import{a}from"./index-BOdEhjVx.js";const o=()=>a(e=>e.features.dashboard.deleteDashboard);export{o as u};
