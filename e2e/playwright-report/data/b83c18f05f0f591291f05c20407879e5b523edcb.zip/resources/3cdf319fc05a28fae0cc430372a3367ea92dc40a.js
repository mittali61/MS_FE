import{fB as s,r as e}from"./index-BOdEhjVx.js";function r(o){const{setActions:t}=s();e.useEffect(()=>(t&&t(o),()=>{t&&t(null)}),[])}export{r as u};
